module.exports = {
  '/kdemo/': {
    target: 'http://localhost:18081/',
  },
}
