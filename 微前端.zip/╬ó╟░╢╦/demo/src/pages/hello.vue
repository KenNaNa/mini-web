<template>
  <div>
    hello 微前端
  </div>
</template>

<script>
export default {
  name: 'hello'
}
</script>