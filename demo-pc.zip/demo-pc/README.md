#添加 mfv-cli-service 依赖
npm install mfv-cli-service -D