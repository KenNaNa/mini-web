# InsertScriptWebpackPlugin 插入脚本插件
[InsertScriptWebpackPlugin](https://github.com/tbhuabi/insert-script-webpack-plugin#readme)

# optimize-css-assets-webpack-plugin 样式优化插件

# https://github.com/micro-frontends-vue/async-routes/blob/master/detail.md


